var DOCUMENTATION_VERSIONS = {
    DEFAULTS: { has_targets: true,
                supported_targets: [ "esp32", "esp32s2" ]
              },
      IDF_TARGETS: [
        { text: "ESP32", value: "esp32" },
        { text: "ESP32-S2", value: "esp32s2" }
      ]
};
