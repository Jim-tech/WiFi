var DOCUMENTATION_VERSIONS = {
    DEFAULTS: { has_targets: false,
              },
    VERSIONS: [
      { name: "latest", old:false},
      { name: "v4.4", old:false},
    ],
};
