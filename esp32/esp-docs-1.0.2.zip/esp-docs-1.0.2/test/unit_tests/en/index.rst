Build docs test index
=====================


.. toctree::

   :esp32s2: ESP32-S2 Page <esp32s2_page>
   :esp32: ESP32 Page !ESP32_CONTENT! <esp32_page>
   :SOC_BT_SUPPORTED: BT Page !BT_CONTENT! <bt_page.rst>
   IDF Target Format <idf_target_format>
