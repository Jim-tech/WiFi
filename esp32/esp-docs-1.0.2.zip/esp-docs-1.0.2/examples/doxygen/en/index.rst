ESP-Docs Simple Example
=========================
:link_to_translation:`zh_CN:[中文]`

This is a simple example for the esp-docs building system.

.. ---------------------------- API Reference ----------------------------------

API Reference
-------------

.. include-build-file:: inc/my_api.inc

.. include-build-file:: inc/my_cxx_api.inc
