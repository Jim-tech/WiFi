build-docs -t esp32 esp32s2 esp32c3 esp32s3 esp32h2 esp8266 esp32c2
