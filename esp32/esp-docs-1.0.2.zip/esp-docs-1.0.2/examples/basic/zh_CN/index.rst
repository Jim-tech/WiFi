ESP-Docs Simple Example
=========================
:link_to_translation:`en:[English]`

This is a simple example for the esp-docs building system. It builds documentation for ESP32 only, English and Chinese version.