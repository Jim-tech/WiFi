# Basic Example

Basic documentation building example that builds English and Chinese documentation for ESP32.