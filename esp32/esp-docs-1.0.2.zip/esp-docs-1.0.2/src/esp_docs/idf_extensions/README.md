See docs/en/contribute/add-ons-reference.rst (or in the IDF docs) for details.

